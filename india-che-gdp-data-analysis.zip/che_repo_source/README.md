# India CHE/GDP Data Analysis (2014–2023)

**IBM SkillsBuild Data Analytics with AI — Academic Internship Project**  
Prepared by: **Ajitesh**

This project explores India's Current Health Expenditure (CHE) as a percentage of GDP over 2014–2023. It demonstrates a reproducible Python workflow covering data validation, year-on-year changes, descriptive statistics, visualisation, and a simple linear trend analysis.

> **Data note:** The repository contains the historical values used for this project. Health expenditure series can be revised by source agencies. Verify the latest observations against the official source before reusing or citing the results. The analysis is descriptive and is not evidence of causation.

## Project objectives

- Organise and validate annual CHE/GDP observations for 2014–2023.
- Calculate descriptive statistics and year-on-year changes.
- Visualise the trend and annual variation.
- Fit a simple linear regression as an exploratory trend, with appropriate limitations.
- Export analysis tables and charts for reporting.

## Repository contents

```text
india-che-gdp-data-analysis/
├── README.md
├── Ajitesh_India_CHE_GDP_Analytics.ipynb  # Jupyter Notebook
├── Ajitesh_India_CHE_GDP_Analytics.py     # Standalone Python script
├── india_che_gdp_2014_2023.csv            # Input dataset
├── requirements.txt                       # Python dependencies
├── .gitignore
└── reports/
    └── Ajitesh_ProjectReport.docx          # Project report
```

The Python script creates a `project_outputs/` folder when run. Generated outputs are not required to run the analysis and are excluded from version control by `.gitignore`.

## Dataset and source

- **Country:** India
- **Indicator:** Current health expenditure (% of GDP)
- **Period:** 2014–2023
- **Indicator code:** `SH.XPD.CHEX.GD.ZS`
- **World Bank indicator page:** https://data.worldbank.org/indicator/SH.XPD.CHEX.GD.ZS?locations=IN
- **World Bank API:** https://api.worldbank.org/v2/country/IND/indicator/SH.XPD.CHEX.GD.ZS?format=json
- **Underlying global health expenditure resource:** WHO Global Health Expenditure Database — https://apps.who.int/nha/database

## Tools used

- Python
- pandas and NumPy
- Matplotlib
- SciPy
- Jupyter Notebook

## Run the project

### 1. Download or clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/india-che-gdp-data-analysis.git
cd india-che-gdp-data-analysis
```

Replace `YOUR-USERNAME` with your actual GitHub username after creating the repository.

### 2. Install dependencies

Python 3.10 or newer is recommended.

```bash
python -m pip install -r requirements.txt
```

### 3. Run the Python script

```bash
python Ajitesh_India_CHE_GDP_Analytics.py
```

### 4. Or run the notebook

```bash
jupyter notebook Ajitesh_India_CHE_GDP_Analytics.ipynb
```

In Jupyter, choose **Run All** to execute the notebook from top to bottom.

## Methodology

1. Load the annual observations.
2. Validate unique years, continuous coverage, missing values, and positive CHE/GDP values.
3. Calculate year-on-year changes in percentage points and percentage terms.
4. Compute descriptive statistics, including mean, median, standard deviation, minimum, maximum, and range.
5. Plot the time series and annual changes.
6. Fit a simple linear regression to describe the overall linear trend.
7. Interpret results in context and note the limitations of a short, single-country time series.

## Interpretation cautions

CHE/GDP is a ratio. Its movement can reflect changes in health expenditure, GDP, or both. It does not independently measure healthcare quality, access, efficiency, or absolute spending. With only ten annual observations, regression results are exploratory and should not be treated as a reliable forecast or causal explanation.

## Academic use

Review the code and report before submission, ensure the dataset matches the latest source requirements from your programme, and add any required student or mentor details. Do not describe the values as live or real-time data.
