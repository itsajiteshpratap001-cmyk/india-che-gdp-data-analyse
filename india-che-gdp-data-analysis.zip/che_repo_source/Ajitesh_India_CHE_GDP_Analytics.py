"""
India CHE/GDP Data Analytics Project
IBM SkillsBuild Data Analytics with AI Academic Internship

Project objective:
Analyse India's Current Health Expenditure (CHE) as a percentage of GDP
for 2014–2023 using data validation, descriptive statistics, visualisation,
year-on-year changes, and simple linear regression.

Data source:
World Bank World Development Indicators, indicator SH.XPD.CHEX.GD.ZS
https://data.worldbank.org/indicator/SH.XPD.CHEX.GD.ZS?locations=IN

Note:
The observations below are the historical values used in this project.
Check the official source for revisions before academic or professional reuse.
"""

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# -----------------------------
# 1. Project configuration
# -----------------------------
OUTPUT_DIR = Path("project_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# Historical observations used in this analysis (percentage of GDP)
data = {
    "Year": [2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023],
    "CHE_percent_GDP": [
        3.6196, 3.5957, 3.5043, 2.9360, 2.8585,
        2.9530, 3.3415, 3.3468, 3.3962, 3.3394
    ],
}

df = pd.DataFrame(data)

# -----------------------------
# 2. Data validation
# -----------------------------
assert df["Year"].is_unique, "Duplicate years detected."
assert df["CHE_percent_GDP"].notna().all(), "Missing CHE/GDP values detected."
assert len(df) == 10, "Expected 10 annual observations."
assert df["Year"].tolist() == list(range(2014, 2024)), "Years must be continuous from 2014 to 2023."
assert (df["CHE_percent_GDP"] > 0).all(), "CHE/GDP values should be positive."

print("=" * 65)
print("INDIA CHE/GDP DATA ANALYTICS PROJECT")
print("=" * 65)
print("\nData validation: PASSED")
print(f"Observations: {len(df)}")
print(f"Period: {df['Year'].min()}–{df['Year'].max()}")

# -----------------------------
# 3. Feature engineering
# -----------------------------
df["YoY_change_percentage_points"] = df["CHE_percent_GDP"].diff()
df["YoY_change_percent"] = df["CHE_percent_GDP"].pct_change() * 100

# -----------------------------
# 4. Descriptive statistics
# -----------------------------
values = df["CHE_percent_GDP"]
descriptive_stats = pd.DataFrame({
    "Measure": [
        "Number of observations",
        "Mean (% of GDP)",
        "Median (% of GDP)",
        "Sample standard deviation (percentage points)",
        "Minimum (% of GDP)",
        "Year of minimum",
        "Maximum (% of GDP)",
        "Year of maximum",
        "Range (percentage points)",
        "Coefficient of variation (%)",
        "2014–2023 change (percentage points)",
        "2014–2023 relative change (%)",
    ],
    "Value": [
        values.count(),
        values.mean(),
        values.median(),
        values.std(ddof=1),
        values.min(),
        int(df.loc[values.idxmin(), "Year"]),
        values.max(),
        int(df.loc[values.idxmax(), "Year"]),
        values.max() - values.min(),
        values.std(ddof=1) / values.mean() * 100,
        values.iloc[-1] - values.iloc[0],
        (values.iloc[-1] / values.iloc[0] - 1) * 100,
    ],
})
print("\nDESCRIPTIVE STATISTICS")
print(descriptive_stats.to_string(index=False, formatters={"Value": lambda x: f"{x:.4f}" if isinstance(x, (float, np.floating)) else str(x)}))

# -----------------------------
# 5. Linear regression
# -----------------------------
regression = stats.linregress(df["Year"], values)
degrees_of_freedom = len(df) - 2
t_critical = stats.t.ppf(0.975, degrees_of_freedom)
ci_low = regression.slope - t_critical * regression.stderr
ci_high = regression.slope + t_critical * regression.stderr

regression_results = pd.DataFrame({
    "Metric": [
        "Slope (percentage points per year)",
        "Intercept",
        "R-squared",
        "p-value",
        "95% CI lower bound for slope",
        "95% CI upper bound for slope",
    ],
    "Value": [
        regression.slope,
        regression.intercept,
        regression.rvalue ** 2,
        regression.pvalue,
        ci_low,
        ci_high,
    ],
})
print("\nLINEAR REGRESSION RESULTS")
print(regression_results.to_string(index=False, formatters={"Value": lambda x: f"{x:.5f}"}))

if regression.pvalue < 0.05:
    print("\nInterpretation: The linear time trend is statistically significant at the 5% level.")
else:
    print("\nInterpretation: The linear time trend is NOT statistically significant at the 5% level.")
print("Caution: regression describes association with time; it does not establish causation.")

# -----------------------------
# 6. Visualisations
# -----------------------------
plt.figure(figsize=(9, 5))
plt.plot(df["Year"], values, marker="o")
plt.title("India: Current Health Expenditure as % of GDP (2014–2023)")
plt.xlabel("Year")
plt.ylabel("CHE (% of GDP)")
plt.xticks(df["Year"])
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "che_gdp_trend.png", dpi=180)
plt.show()

plt.figure(figsize=(9, 5))
plt.bar(df["Year"].astype(str), df["YoY_change_percentage_points"])
plt.axhline(0, linewidth=1)
plt.title("Year-on-Year Change in India's CHE/GDP Ratio")
plt.xlabel("Year")
plt.ylabel("Change (percentage points)")
plt.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "che_gdp_yoy_change.png", dpi=180)
plt.show()

# -----------------------------
# 7. Export results
# -----------------------------
df.to_csv(OUTPUT_DIR / "india_che_gdp_2014_2023.csv", index=False)
descriptive_stats.to_csv(OUTPUT_DIR / "descriptive_statistics.csv", index=False)
regression_results.to_csv(OUTPUT_DIR / "regression_results.csv", index=False)

print("\nFILES EXPORTED")
for filename in [
    "india_che_gdp_2014_2023.csv",
    "descriptive_statistics.csv",
    "regression_results.csv",
    "che_gdp_trend.png",
    "che_gdp_yoy_change.png",
]:
    print(f"- {OUTPUT_DIR / filename}")

print("\nKEY FINDINGS")
print(f"- Average CHE/GDP ratio: {values.mean():.3f}%")
print(f"- Minimum: {values.min():.4f}% in {int(df.loc[values.idxmin(), 'Year'])}")
print(f"- Maximum: {values.max():.4f}% in {int(df.loc[values.idxmax(), 'Year'])}")
print(f"- Net change, 2014–2023: {values.iloc[-1] - values.iloc[0]:+.4f} percentage points")
print(f"- Linear trend R-squared: {regression.rvalue ** 2:.4f}")
print("\nInterpret CHE/GDP carefully: it can change because healthcare spending, GDP, or both change.")
